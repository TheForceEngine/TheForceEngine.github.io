The Force Engine
Pre-Release / Pre-Alpha Build
Version 0.01.006

WHAT IS THE FORCE ENGINE?
==============================================
The Force Engine is a project to reverse engineer and rebuild the Jedi Engine for modern systems and the games that used that engine - Dark Forces and Outlaws. The project includes modern, built-in tools, such as a level editor and makes it easy to play Dark Forces and Outlaws on modern systems as well as the many community mods designed to work with the original games.

Several years ago there was a project called the “XL Engine” which evolved from DarkXL with lofty ambitions. I personally hit some difficult times but never properly canceled the project, even if I couldn’t get back to it for a long time and didn’t really want to for a long time after that. Fast forward to today, things are much better now with more free time but time moves on and the XL Engine isn’t really necessary anymore - both Daggerfall and Blood have great projects that fill the niche the XL Engine wanted to fill (or close enough).

But the Jedi Engine never had a proper source release or reverse engineering effort. While many considered DarkXL to be a promising effort, it was incomplete and inaccurate in many ways. Ultimately the methods used to reproduce the game could never be 100% faithful in the ways that matter. And so The Force Engine was concieved as a complete re-write, rebuilt from the ground up with the following tenets:

* Support all Jedi based games - Dark Forces and Outlaws.
* Source-level accuracy by reverse engineering the original executables.
* Focus on making sure the core games are completely supported before adding effects on top like dynamic lighting, this means starting with the software renderer just like the originals.
* Open sourcing the project the moment it goes public.
* Cross platform support (though admittadly this last area still needs a lot of work before the first release).

PREAMBLE
==============================================
Please visit https://theforceengine.github.io/ for more information about the current state of the project, to visit the forums, report bugs and so forth.
This is a pre-release build meant mostly for testing.
This build works only on 64 bit Windows and OpenGL 3.3 is required - though the requirements will be lowered for release.

This build is NOT complete - most of the work is currently focused on the reverse-engineering effort whis is currently incomplete. Currently only Dark Forces is supported, though some Outlaws assets can be loaded by the editors.
THIS IS NOT YET A DOSBOX REPLACEMENT - THIS BUILD IS ONLY FOR TESTING.

BUILD CONTENTS
============================================
When starting the application you will be greeted by a very barebones menu. Of the options listed, the following options are functional:
[Start] - start up Dark Forces. You will be taken directly to the Agent Menu with pre-set game data. You can create and delete agents but nothing is saved to disk. Pick a level and begin mission to get started. The mission briefing and cutscenes are currently not shown.
[Configure] - Setup game source paths and graphics settings.
[Editor] - open the asset editors.
[Exit] - exit the application.

Start
============================================
Currently only "classic" software rendering is supported with a default of 320x200. You can change the internal resolution in the settings.ini file, which can be found at /Documents/TheForceEngine/settings.ini. When changing the resolution, please pick 4:3 resolutions (except for 320x200) - widescreen is not yet supported. In fullscreen, the display will be letterboxed to fit within the desktop resolution. Example resolutions include 320x200, 640x480, 800x600, 1440x1080, etc. Note that performance will be low with higher resolutions, the renderer is not well optimized yet (until the reverse-engineering is complete and it is 100% accurate).

Note that you can also change to fullscreen and adjust other settings. You can change from fullscreen / windowed at any time while running by hitting F11.

Here is what is currently working:
* All INF is working in the base levels (including areas where DarkXL struggled).
* All levels are completable, though you will have to crouch jump to grab some items due to a collision bug.
* AI is not functional, but you can kill enemies. Enemies will drop required items and killing bosses will have the correct effect. This is why the levels can be completed.
* Only the Bryar Pistol and Thermal detonator weapons work. There is infinite ammo. But exploding walls work correctly.
* Basic midi music works - but no dynamic iMuse.
* Movement, collision, etc. work but are not yet accurate.
* The ESC menu works but most options do not (Abort/Next mission, Exit).
* Some sound effects are missing.
* Controls are not rebindable.

-------------------------------------------------
                 Controls
-------------------------------------------------
Move/Strafe        WASD
Turn Left          Left Arrow / Mouse Look
Turn Right         Right Arrow / Mouse Look
Look Up            PageUp / Mouse Look
Look Down          PageDn / Mouse Look
Recenter           End
Jump               Spacebar
Crouch             Left Control
Run                Shift
Use                E
Primary Fire       Left Mouse Button
Weapon Sel         1, 2, 3, 4  (only 2 & 4 function)
Night Vision       F2
Headlight          F5
Menu               ESC  (only Abort/Next Mission, Quit to Dos and Return To Game function)
FPS Display        F9
Fullscreen Toggle  F11
Console            ` (also '~' on US keyboards)
Screenshot         PrintScreen


Editor
============================================
When you hit the Editor button, you will see a menu at the top and "Archive Viewer" to the left. You can hit "Open Archive" to view the contents of GOB, LAB and LFD files. You will see the contents of the archive listed on the left, click on an item to view it. Use the right mouse botton to pan around level maps. You can also open custom GOBs and even play mod levels.

Under the EDITOR menu (top left), you can select the LEVEL EDITOR or return to the main menu.

Level Editor
============================================
Currently only pre-set levels can be opened. File->Recent->Levels.
Use WASD to scroll the view, mouse wheel to zoom. There are a number of options, such as the view mode (View menu).
Hold the Right Mouse button to rotate the view in 3D mode.

You can view the listed levels, change layers, select sectors, walls, vertices and entities (and check out their settings). In 3D mode, you can hit PLAY to start the game from the current camera location (Run menu or play button). If you have the "emulatorPath" set up in the settings.ini, you can use the Run menu to launch in DosBox as well (for example: emulatorPath="C:/Program Files (x86)/Steam/steamapps/common/dark forces/"). You can also change sector, wall, vertex or entitie settings using the right hand "Info Panel." Finally if a sector or wall is selected with a INF script setup, you can see it by selecting "Edit INF Script" in the info panel.

There are a lot of features that I am glossing over. There will be more documentation in the future.

This is an early preview and most proper editing functionality is currently disabled.