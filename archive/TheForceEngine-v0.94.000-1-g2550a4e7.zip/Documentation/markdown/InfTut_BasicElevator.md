# Tutorial: Basic Elevator
TODO

**Prev:** [Switch Door](local://InfTut_SwitchDoor)
## Contents
  * [Interactive Level Elements: Tutorials](local://Inf_Tutorials)
  * [Basic Door](local://InfTut_BasicDoor)
  * [Red Key Door](local://InfTut_RedKeyDoor)
  * [Door Opened by a Switch](local://InfTut_SwitchDoor)
  * [Basic Elevator](local://InfTut_BasicElevator)