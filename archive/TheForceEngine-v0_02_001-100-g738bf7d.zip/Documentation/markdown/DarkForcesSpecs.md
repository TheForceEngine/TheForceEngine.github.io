# Dark Forces Specs
Dark Forces Specs
### Version
1.0.00
### Runtime File Formats
  * [WAX](local://DarkForcesSpecs/WaxFormat)