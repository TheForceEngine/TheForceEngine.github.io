The Force Engine
CGL Prelease Build
Version 0.90.000

WHAT IS THE FORCE ENGINE?
==============================================
The Force Engine is a project with the goal to reverse engineer and rebuild the Jedi Engine for modern systems and the games that used that engine - Dark Forces and Outlaws. The project will include modern, built-in tools, such as a level editor and will make it easy to play Dark Forces and Outlaws on modern systems as well as the many community mods designed to work with the original games.

Playing Dark Forces or Outlaws using the Force Engine will add ease of use and modern features such as higher resolutions and modern control schemes such as mouse-look. Using the built-in tools will allow for easier modding with more modern UI, greater flexibility and the ability to use enhancements made to the Jedi Engine for Outlaws in custom Dark Forces levels - such as slopes, stacked sectors, per-sector color maps and more.

Note that while Dark Forces support is nearly complete (version 0.8), Outlaws is not playable yet - the focus so far has been on the framework, Dark Forces support, and JEDI reverse-engineering. However, Outlaws support is planned and will be complete in TFE version 2.0. See Current State below.

CURRENT STATE
==============================================
The project is in a pre-release state, version 0.9. While it shares a legacy with DarkXL, it is a complete rewrite - rebuilt from the ground up with a much greater focus on accuracy. It is much more focused than the XL Engine, focused on being a Jedi Engine replacement/port only - thus full support for Dark Forces and later Outlaws. Please check the Roadmap for more information on release timetable and planned feature-set.

PREAMBLE
==============================================
Please visit https://theforceengine.github.io/ for more information about the current state of the project, to visit the forums, report bugs and so forth.
This is a pre-release build meant mostly for testing.
This build works only on 64 bit Windows and OpenGL 3.3 is required - though the requirements will be lowered for release.

This build is incomplete and has several known issues. However, the code is now based on fully reverse-engineered code and is a solid base on which the project will continue to build.
THIS IS NOT YET A DOSBOX REPLACEMENT - THIS BUILD IS ONLY FOR TESTING.

BUILD CONTENTS
============================================
When starting the application, you will see a menu with several options:
START     - start the current game (only Dark Forces at this point).
MANUAL    - rough manual, not very useful yet.
CREDITS   - credits for contributors and open source libraries used.
SETTTINGS - adjust settings, see below.
MODS      - nothing yet, but this will allow you to easily load game mods in the future.
EDITOR    - currently disabled, do not press.
EXIT      - exit the application. You can also use Alt+F4 at any time.

Setting up Game Data
============================================
TFE requires the original Dark Forces game data to run. The application should auto-detect the Dark Forces directory for most people. However, if this does not work for you, select Settings from the menu and then Game. From there hit the Browse button next to Dark Forces and then select DARK.EXE from your Dark Forces installation. You can also manually enter the directory.

For example, with Steam this will probably be "C:/program files (x86)/steam/SteamApps/common/dark forces/Game/"

Start
============================================
Currently only the software renderer is available, but it supports the original 320x200 and resolutions up to 4k, including widescreen support.
Note that you can also change to fullscreen and adjust other settings. You can change from fullscreen / windowed at any time while running by hitting F11.

Here is what is currently working:
* All game system are now functional though there are still bugs.

Known issues - 
Some of these are bugs, others simply haven't been integrated or implemented yet.
* Mines trigger through closed doors.
* Players slip on rotating sectors.
* LAIMLAME does not project you from health damage.

-------------------------------------------------
                 Controls
-------------------------------------------------
See https://theforceengine.github.io/TFE_Manual for the full list of controls.