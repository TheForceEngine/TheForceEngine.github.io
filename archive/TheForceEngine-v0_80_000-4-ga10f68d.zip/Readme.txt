The Force Engine
CGL Prelease Build
Version 0.80.000

WHAT IS THE FORCE ENGINE?
==============================================
The Force Engine is a project to reverse engineer and rebuild the Jedi Engine for modern systems and the games that used that engine - Dark Forces and Outlaws. The project includes modern, built-in tools, such as a level editor and makes it easy to play Dark Forces and Outlaws on modern systems as well as the many community mods designed to work with the original games.

Several years ago there was a project called the “XL Engine” which evolved from DarkXL with lofty ambitions. I personally hit some difficult times but never properly canceled the project, even if I couldn’t get back to it for a long time and didn’t really want to for a long time after that. Fast forward to today, things are much better now with more free time but time moves on and the XL Engine isn’t really necessary anymore - both Daggerfall and Blood have great projects that fill the niche the XL Engine wanted to fill (or close enough).

But the Jedi Engine never had a proper source release or reverse engineering effort. While many considered DarkXL to be a promising effort, it was incomplete and inaccurate in many ways. Ultimately the methods used to reproduce the game could never be 100% faithful in the ways that matter. And so The Force Engine was concieved as a complete re-write, rebuilt from the ground up with the following tenets:

* Support all Jedi based games - Dark Forces and Outlaws.
* Source-level accuracy by reverse engineering the original executables.
* Focus on making sure the core games are completely supported before adding effects on top like dynamic lighting, this means starting with the software renderer just like the originals.
* Open sourcing the project the moment it goes public.
* Cross platform support (though admittadly this last area still needs a lot of work before the first release).

PREAMBLE
==============================================
Please visit https://theforceengine.github.io/ for more information about the current state of the project, to visit the forums, report bugs and so forth.
This is a pre-release build meant mostly for testing.
This build works only on 64 bit Windows and OpenGL 3.3 is required - though the requirements will be lowered for release.

This build is incomplete and has several known issues. However, the code is now based on fully reverse-engineered code and is a solid base on which the project will continue to build.
THIS IS NOT YET A DOSBOX REPLACEMENT - THIS BUILD IS ONLY FOR TESTING.

BUILD CONTENTS
============================================
When starting the application, you will see a menu with several options:
START     - start the current game (only Dark Forces at this point).
MANUAL    - rough manual, not very useful yet.
CREDITS   - credits for contributors and open source libraries used.
SETTTINGS - adjust settings, see below.
MODS      - nothing yet, but this will allow you to easily load game mods in the future.
EDITOR    - currently disabled, do not press.
EXIT      - exit the application. You can also use Alt+F4 at any time.

Setting up Game Data
============================================
TFE requires the original Dark Forces game data to run. The application should auto-detect the Dark Forces directory for most people. However, if this does not work for you, select Settings from the menu and then Game. From there hit the Browse button next to Dark Forces and then select DARK.EXE from your Dark Forces installation. You can also manually enter the directory.

For example, with Steam this will probably be "C:/program files (x86)/steam/SteamApps/common/dark forces/Game/"

Start
============================================
Currently only "classic" software rendering is supported with a default of 320x200. The floating-point sub-renderer will be re-enabled in a future build.

Note that you can also change to fullscreen and adjust other settings. You can change from fullscreen / windowed at any time while running by hitting F11.

Here is what is currently working:
* INF is working (except for bugs).
* TFE will use Dark Forces save data.
* You can create new agents, delete them, and play any mission.
* Most levels can be finished, except those that require defeating a Phase 2 Dark Trooper, Boba Fett or General Mohc.
* All AI has been integrated, except for the 3 bosses mentioned above.
* All weapons work, including secondary fire.
* All pickups work.
* All cheat codes work except for LAREDLITE. Though LAIMLAME incorrectly allows you to take health damage.

Known issues - 
Some of these are bugs, others simply haven't been integrated or implemented yet.
* Sometimes "hit effects" trigger too high when shooting enemies.
* Gromas Mines' cliffside near the elevator into the facility has a HOM when you look up.
* Mines trigger through closed doors.
* Players slip on rotating sectors.
* Phase 1 teleports and has trouble when losing sight of the player.
* Enemies have buggy movement when hitting solid walls, drops, or ledges that are too high.
* LAIMLAME does not project you from health damage.
* LAREDLITE does nothing.
* The Moudly Crow does not return at the end of Test Base (though the level can still be finished).
* Shield pickups have collision with thermal detonators.
* Health damage flashes too fast when taking major damage.
* Probe Droid explosions have a very small radius. 
* The System UI doesn't quite work fully.
* Sound volumes and attenuation do not match DOS.
* Only 320x200 is supported for now, widescreen and higher resolutions will be coming back soon.
* Cutscenes do not work.
* Mission briefings do not work.
* iMuse does not work - the fight track does not play (but the base track does).
* You cannot bring up the PDA.
* The Config option in the Escape menu does nothing.

-------------------------------------------------
                 Controls
-------------------------------------------------
See https://theforceengine.github.io/TFE_Manual for the full list of controls.