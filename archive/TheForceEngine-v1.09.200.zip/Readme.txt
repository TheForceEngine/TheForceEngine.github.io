The Force Engine
Version 1.09.2

A purchased copy of the original game is required and is not provided by The Force Engine. The documentation (the manual accessible from the main menu or https://theforceengine.github.io/Documentation.html) has information on how to legally purchase Dark Forces. TFE is not a remaster, it is essentially a source port designed to run the original game natively on modern systems with quality of life improvements and optional enhancements. Dark Forces and Outlaws are owned by Disney and are still active, commercial products. The IP is owned solely by Disney.

WHAT IS THE FORCE ENGINE?
==============================================
The Force Engine is a project with the goal to reverse engineer and rebuild the Jedi Engine for modern systems and the games that used that engine - Dark Forces and Outlaws. The project will include modern, built-in tools, such as a level editor and will make it easy to play Dark Forces and Outlaws on modern systems as well as the many community mods designed to work with the original games.

Playing Dark Forces or Outlaws using the Force Engine will add ease of use and modern features such as higher resolutions and modern control schemes such as mouse-look. Using the built-in tools will allow for easier modding with more modern UI, greater flexibility and the ability to use enhancements made to the Jedi Engine for Outlaws in custom Dark Forces levels - such as slopes, stacked sectors, per-sector color maps and more.

Dark Forces support is complete, and Outlaws is not playable yet - the focus so far has been on the framework, Dark Forces support, and JEDI reverse-engineering. However, Outlaws support is planned and will be complete in TFE version 2.0. See Current State below.

CURRENT STATE
==============================================
Support for Dark Forces is complete. While there are still bugs, the game and most mods are fully playable. Dark Forces support is feature complete.

While the project shares a legacy with DarkXL, it is a complete rewrite - rebuilt from the ground up with a much greater focus on accuracy. It is much more focused than the XL Engine, focused on being a Jedi Engine replacement/port only - thus full support for Dark Forces and later Outlaws. Please check the Roadmap for more information on release timetable and planned feature-set.

PREAMBLE
==============================================
Please visit https://theforceengine.github.io/ for more information about the current state of the project, to visit the forums, report bugs and so forth.

This build can now be used as a DosBox replacement for Dark Forces for most purposes (speed running might be an exception). Outlaws is not yet playable.

This build works only on 64 bit Windows and OpenGL 3.3 is required - though the requirements will be lowered soon after version 1.0.

BUILD CONTENTS
============================================
When starting the application, you will see a menu with several options:
START     - start the current game (only Dark Forces at this point).
MANUAL    - rough manual, not very useful yet.
CREDITS   - credits for contributors and open source libraries used.
SETTINGS  - adjust settings, see below.
MODS      - choose mods from the list, which are grabbed for your Mods/ directory. Place zip files or a directory per-mod.
EDITOR    - currently disabled, but will be reactivated soon.
EXIT      - exit the application. You can also use Alt+F4 at any time.

Setting up Game Data
============================================
TFE requires the original Dark Forces game data to run. The application should auto-detect the Dark Forces directory for most people. However, if this does not work for you, select Settings from the menu and then Game. From there hit the Browse button next to Dark Forces and then select DARK.EXE from your Dark Forces installation. You can also manually enter the directory.

For example, with Steam this will probably be "C:/program files (x86)/steam/SteamApps/common/dark forces/Game/"

Start
============================================
Go to settings to choose the desired resolution and renderer. The GPU Renderer allows for looking up and down with correct perspective. If you choose the software renderer and run at 320x200 it will use the original DOS renderer.

Note that you can also change to fullscreen and adjust other settings. You can change from fullscreen / windowed at any time 

-------------------------------------------------
Notes
-------------------------------------------------
On the main menu, select Manual to see important default controls. Open the input menu to see possible actions and current bindigs. These bindings and other settings, such as mouse sensitivity, can also be changed.